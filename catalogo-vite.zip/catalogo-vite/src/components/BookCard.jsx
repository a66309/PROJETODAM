import { useState } from 'react'

function BookCard({ livro }) {
  const [detalhesVisiveis, setDetalhesVisiveis] = useState(false)

  return (
    <article className="book-card">
      <img className="book-cover" src={livro.capa} alt={`Capa de ${livro.titulo}`} />
      <h3 className="book-title">{livro.titulo}</h3>
      <p className="book-author">{livro.autor}</p>
      <button
        className="btn-outline"
        type="button"
        aria-expanded={detalhesVisiveis}
        onClick={() => setDetalhesVisiveis((visivel) => !visivel)}
      >
        {detalhesVisiveis ? 'Ocultar detalhes' : 'Ver detalhes'}
      </button>
      {detalhesVisiveis && (
        <div className="book-details">
          <p><strong>Ano:</strong> {livro.ano}</p>
          <p><strong>Opinião:</strong> {livro.opiniao}</p>
        </div>
      )}
    </article>
  )
}

export default BookCard
