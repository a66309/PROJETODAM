import { useState } from 'react'

function BookForm({ onAdicionar }) {
  // Campos controlados com useState
  const [titulo, setTitulo] = useState('')
  const [autor, setAutor] = useState('')
  const [ano, setAno] = useState('')
  const [capa, setCapa] = useState('')
  const [erroCapa, setErroCapa] = useState('')
  const [opiniao, setOpiniao] = useState('')

  function handleCapaChange(evento) {
    const ficheiro = evento.target.files?.[0]
    setErroCapa('')

    if (!ficheiro) {
      setCapa('')
      return
    }

    if (!ficheiro.type.startsWith('image/')) {
      setCapa('')
      setErroCapa('Escolha um ficheiro de imagem válido.')
      evento.target.value = ''
      return
    }

    const leitor = new FileReader()
    leitor.onload = () => {
      if (typeof leitor.result === 'string') {
        setCapa(leitor.result)
      } else {
        setErroCapa('Não foi possível carregar a imagem escolhida.')
      }
    }
    leitor.onerror = () => {
      setCapa('')
      setErroCapa('Não foi possível carregar a imagem escolhida.')
    }
    leitor.readAsDataURL(ficheiro)
  }

  function handleSubmit(evento) {
    evento.preventDefault() // evita recarregar a página

    const novoLivro = {
      id: Date.now(),
      titulo: titulo,
      autor: autor,
      ano: Number(ano),
      capa: capa || 'https://via.placeholder.com/120x180?text=Sem+capa',
      opiniao,
    }

    onAdicionar(novoLivro)

    // Limpar o formulário
    setTitulo('')
    setAutor('')
    setAno('')
    setCapa('')
    setErroCapa('')
    setOpiniao('')
    evento.currentTarget.reset()
  }

  return (
    <form className="book-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="titulo">Título</label>
        <input
          id="titulo"
          type="text"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="autor">Autor</label>
        <input
          id="autor"
          type="text"
          value={autor}
          onChange={(e) => setAutor(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="ano">Ano</label>
        <input
          id="ano"
          type="number"
          value={ano}
          onChange={(e) => setAno(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="capa">Imagem da capa (opcional)</label>
        <input
          id="capa"
          type="file"
          accept="image/*"
          onChange={handleCapaChange}
        />
        {erroCapa && <p role="alert">{erroCapa}</p>}
      </div>

      <div className="form-group">
        <label htmlFor="opiniao">Opinião</label>
        <textarea
          id="opiniao"
          value={opiniao}
          onChange={(e) => setOpiniao(e.target.value)}
          required
        />
      </div>

      <button className="btn-solid" type="submit">Adicionar livro</button>
    </form>
  )
}

export default BookForm
